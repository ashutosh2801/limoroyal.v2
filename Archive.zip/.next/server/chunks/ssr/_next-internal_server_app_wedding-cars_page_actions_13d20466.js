module.exports=[10408,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_wedding-cars_page_actions_13d20466.js.map