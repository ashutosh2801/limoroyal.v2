module.exports=[98883,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_airport-transfers_page_actions_b59129eb.js.map