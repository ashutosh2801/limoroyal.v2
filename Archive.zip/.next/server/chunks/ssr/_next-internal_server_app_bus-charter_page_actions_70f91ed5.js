module.exports=[76829,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bus-charter_page_actions_70f91ed5.js.map