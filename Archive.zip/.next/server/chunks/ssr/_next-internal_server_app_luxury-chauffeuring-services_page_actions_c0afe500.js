module.exports=[74170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_luxury-chauffeuring-services_page_actions_c0afe500.js.map