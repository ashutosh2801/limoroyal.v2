module.exports=[9397,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_luxury-limousine_page_actions_0a4c6bdc.js.map