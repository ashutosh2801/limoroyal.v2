module.exports=[87593,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_areas-served_page_actions_f51f23ca.js.map