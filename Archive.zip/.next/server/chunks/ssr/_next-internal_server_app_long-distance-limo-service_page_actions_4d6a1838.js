module.exports=[24575,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_long-distance-limo-service_page_actions_4d6a1838.js.map