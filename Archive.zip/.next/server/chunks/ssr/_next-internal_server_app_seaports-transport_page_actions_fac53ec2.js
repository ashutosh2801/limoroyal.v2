module.exports=[24437,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_seaports-transport_page_actions_fac53ec2.js.map