module.exports=[45671,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_sitemap_page_actions_538cfc2a.js.map