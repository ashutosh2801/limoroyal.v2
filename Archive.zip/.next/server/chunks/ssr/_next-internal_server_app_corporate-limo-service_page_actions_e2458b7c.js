module.exports=[2428,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_corporate-limo-service_page_actions_e2458b7c.js.map