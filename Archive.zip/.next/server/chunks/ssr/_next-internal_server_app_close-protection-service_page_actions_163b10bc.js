module.exports=[87195,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_close-protection-service_page_actions_163b10bc.js.map