module.exports=[20330,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_promotions_page_actions_55f92747.js.map