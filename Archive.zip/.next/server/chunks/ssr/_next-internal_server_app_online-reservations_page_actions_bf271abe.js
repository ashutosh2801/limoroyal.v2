module.exports=[60928,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_online-reservations_page_actions_bf271abe.js.map