globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e9929ae93b25406c.js",
    "static/chunks/5e5b5fb1a028c55c.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/55825b216849be65.js",
    "static/chunks/turbopack-c4982d67a8237622.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];