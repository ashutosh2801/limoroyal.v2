(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a2912b7f._.css",
  "static/chunks/_2d130ed8._.js",
  "static/chunks/node_modules_next_624244a6._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_@heroicons_react_24_solid_esm_c1511d4c._.js"
],
    source: "dynamic"
});
