(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_02124c7f._.js",
  "static/chunks/node_modules_@fortawesome_fontawesome-svg-core_6a30e874._.js",
  "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_e676fced._.js",
  "static/chunks/node_modules_695e383f._.js"
],
    source: "dynamic"
});
